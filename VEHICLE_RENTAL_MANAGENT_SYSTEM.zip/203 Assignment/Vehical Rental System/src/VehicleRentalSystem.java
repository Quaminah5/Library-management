import java.util.Scanner;

public class VehicleRentalSystem {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Create a RentalAgency and add some vehicles
        RentalAgency agency = new RentalAgency();
        agency.addVehicle(new Car("C1", "RoyceRoyce", 5000));
        agency.addVehicle(new Motorcycle("M1", "Yamaha R8", 700));
        agency.addVehicle(new Truck("T1", "Ford F-950", 8000));

        // Get customer information
        System.out.print("Enter your name: ");
        String name = scanner.nextLine();

        String contactNumber;
        while (true) {
            System.out.print("Enter your contact number (10 digits): ");
            contactNumber = scanner.nextLine();
            if (contactNumber.length() == 10) {
                break;
            } else {
                System.out.println("Error: Contact number must be exactly 10 digits.");
            }
        }

        Customer customer = new Customer(name, contactNumber);

        // Display available vehicles
        agency.displayAvailableVehicles();

        // Rent a vehicle
        System.out.print("\nEnter the vehicle ID you want to rent: ");
        String vehicleId = scanner.nextLine();

        Vehicle selectedVehicle = agency.findVehicleById(vehicleId);
        if (selectedVehicle != null && selectedVehicle instanceof Rentable) {
            System.out.print("Enter number of days to rent: ");
            int days = scanner.nextInt();
            ((Rentable) selectedVehicle).rent(customer, days);
        } else {
            System.out.println("Vehicle not found or unavailable.");
        }

        System.out.println("\nThank you for using our Vehicle Rental Service!");
        scanner.close();
    }
}

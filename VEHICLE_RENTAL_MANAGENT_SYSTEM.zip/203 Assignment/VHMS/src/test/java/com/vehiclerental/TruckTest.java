package com.vehiclerental;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class TruckTest {
    @Test
    void testTruckRentalCost() {
        Truck truck = new Truck("T1", "Ford F-150", 100);
        double cost = truck.calculateRentalCost(2);
        assertEquals(250, cost); // 2 * 100 + 50 surcharge
    }
}

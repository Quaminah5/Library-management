package com.vehiclerental;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class VehicleTest {
    @Test
    void testVehicleAvailability() {
        Vehicle car = new Car("C1", "Toyota Corolla", 50);
        assertTrue(car.isAvailable());
        car.setAvailable(false);
        assertFalse(car.isAvailable());
    }
}

package com.vehiclerental;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class RentalAgencyTest {
    @Test
    void testAddAndFindVehicle() {
        RentalAgency agency = new RentalAgency();
        Car car = new Car("C1", "Tesla Model 3", 70);
        agency.addVehicle(car);

        Vehicle foundVehicle = agency.findVehicleById("C1");
        assertNotNull(foundVehicle);
        assertEquals("Tesla Model 3", foundVehicle.getModel());
    }
}

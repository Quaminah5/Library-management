package com.vehiclerental;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class CarTest {
    @Test
    void testCarRentalCost() {
        Car car = new Car("C1", "Honda Civic", 60);
        double cost = car.calculateRentalCost(3);
        assertEquals(180, cost);
    }

    @Test
    void testCarRent() {
        Car car = new Car("C2", "Mazda 3", 55);
        Customer customer = new Customer("Alice", "1234567890");
        car.rent(customer, 2);
        assertFalse(car.isAvailable());
    }
}

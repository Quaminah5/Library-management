package com.vehiclerental;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class MotorcycleTest {
    @Test
    void testMotorcycleRentalCost() {
        Motorcycle motorcycle = new Motorcycle("M1", "Yamaha R3", 40);
        double cost = motorcycle.calculateRentalCost(4);
        assertEquals(160, cost);
    }
}

## **Vehicle Rental Management System**

### **Project Overview**

The **Vehicle Rental Management System** is a Java-based application that demonstrates key Object-Oriented Programming (OOP) principles such as **Encapsulation**, **Inheritance**, **Polymorphism**, **Abstraction**, and **Composition**. The system allows customers to rent different types of vehicles, including cars, motorcycles, and trucks, while incorporating rental calculations, customer management, and business logic.

### **Key Features**

- **Vehicle Management**: Rent and return vehicles like Cars, Motorcycles, and Trucks.
- **Customer Management**: Track customer details and rental history.
- **Dynamic Rental Pricing**: Different rental rates and rules based on vehicle type.
- **Loyalty Program**: Interface-based design for managing customer loyalty.
- **Exception Handling**: Custom exceptions for specific rental scenarios.
- **Interactive CLI**: User-friendly console interface for renting vehicles.
- **Comprehensive Testing**: Unit tests for all core classes.

### **Setup Instructions**

1. **Prerequisites**:
    - Java 11 or higher installed.
    - Maven installed.
    - IntelliJ IDEA or any preferred IDE.

2. **Clone the Repository**:
   ```bash
OOP Principles Demonstrated
Encapsulation:

All fields are private with controlled access via getters and setters.
Input validation ensures data integrity.
Inheritance:

Car, Motorcycle, and Truck classes inherit from the abstract Vehicle class.
Polymorphism:

Method overriding for rental calculations and availability checks.
Interface-based design for renting and returning vehicles.
Abstraction:

Abstract class Vehicle defines core behavior for all vehicle types.
Composition:

RentalAgency and Customer classes interact through composition.

vehicle-rental-system/
├── pom.xml
└── src/
├── main/
│   └── java/
│       └── com/
│           └── vehiclerental/
│               ├── Vehicle.java
│               ├── Car.java
│               ├── Motorcycle.java
│               ├── Truck.java
│               ├── Customer.java
│               ├── RentalAgency.java
│               └── VehicleRentalSystem.java
└── test/
└── java/
└── com/
└── vehiclerental/
├── VehicleTest.java
├── CarTest.java
├── MotorcycleTest.java
├── TruckTest.java
└── RentalAgencyTest.java

Build the Project:
mvn clean install

4.Run the Application:

Open the project in IntelliJ IDEA.
Navigate to VehicleRentalSystem.java.
Run the file using Shift + F10 or the Run button.

5.Usage
Start the Application.
Enter Customer Details (Name and 10-digit contact number).
Choose a Vehicle (Car, Motorcycle, or Truck).
Select Rental Duration (number of days).
The system will display the rental cost and confirm the rental.
Return the vehicle once finished.

6.Testing
The project includes unit tests for core classes using JUnit 5.

Run Tests via Maven:
mvn test

Test Coverage:

VehicleTest: Tests for abstract vehicle behaviors.
CarTest: Tests for car-specific rental logic.
MotorcycleTest: Tests for motorcycle-specific rental logic.
TruckTest: Tests for truck-specific rental logic.
RentalAgencyTest: Tests for rental agency operations.


